date
python /home/costerwell/Apps/AMYCNE-master/AMYCNE.py --call --gc gc_content.tab --coverage $1  --output $2.amycne.out
date
