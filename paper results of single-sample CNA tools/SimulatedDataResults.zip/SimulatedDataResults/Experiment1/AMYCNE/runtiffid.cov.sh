date
python /home/costerwell/Apps/TIDDIT-master/TIDDIT.py --cov --bam $1 -o $2.coverage  -z 1000 
date
