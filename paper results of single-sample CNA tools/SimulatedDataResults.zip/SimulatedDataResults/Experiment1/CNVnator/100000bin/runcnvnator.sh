printf "#1.>>>EXTRACTING READ MAPPING FROM BAM/SAM FILES\n" 
date
/media/costerwell/e06edb98-baff-427a-81c7-0c5a917b2510/home/costerwell/Apps/CNVnator-0.3.2/cnvnator -genome hg19 -root $2.out -tree $1
printf "#2.>>>GENERATING A HISTOGRAM\n"
date
/media/costerwell/e06edb98-baff-427a-81c7-0c5a917b2510/home/costerwell/Apps/CNVnator-0.3.2/cnvnator -genome hg19 -root $2.out -his 100000 -d ~/fasta/hg19/
printf "#3>>>CALCULATING STATISTICS\n"
date
/media/costerwell/e06edb98-baff-427a-81c7-0c5a917b2510/home/costerwell/Apps/CNVnator-0.3.2/cnvnator -root $2.out -stat  100000 
printf "#>>>RD SIGNAL PARTITIONING\n"
date
/media/costerwell/e06edb98-baff-427a-81c7-0c5a917b2510/home/costerwell/Apps/CNVnator-0.3.2/cnvnator -root  $2.out -partition 100000
printf "#>>>CNV CALLING for $2 "
date
/media/costerwell/e06edb98-baff-427a-81c7-0c5a917b2510/home/costerwell/Apps/CNVnator-0.3.2/cnvnator -root $2.out -call 100000 > $2.CNVs.cnvnator.out
date
printf "done"
